-- Creazione del database TOYGROUP
CREATE DATABASE TOYGROUP;

-- Creazione della tabella Category
CREATE TABLE Category (
    CategoryID INT PRIMARY KEY,
    Name VARCHAR(255)
);

-- Creazione della tabella Product
CREATE TABLE Product (
    ProductID INT PRIMARY KEY,
    Name VARCHAR(255),
    CategoryID INT,
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID)
);

-- Creazione della tabella Region
CREATE TABLE Region (
    RegionID INT PRIMARY KEY,
    Name VARCHAR(255)
);

-- Creazione della tabella State
CREATE TABLE State (
    StateID INT PRIMARY KEY,
    Name VARCHAR(255),
    RegionID INT,
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);

-- Creazione della tabella Sales
CREATE TABLE Sales (
    SalesID INT PRIMARY KEY,
    ProductID INT,
    StateID INT,
    SaleDate DATE,
    Quantity INT,
    Price DECIMAL(10, 2),
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (StateID) REFERENCES State(StateID)
);

-- Inserimento dati nella tabella Category
INSERT INTO Category (CategoryID, Name)
VALUES
    (1, 'Action Figures'),
    (2, 'Bambole'),
    (3, 'Costruzioni'),
    (4, 'Giochi da Tavolo'),
    (5, 'Puzzle'),
    (6, 'Robot'),
    (7, 'Veicoli'),
    (8, 'Peluche'),
    (9, 'Giochi di Società'),
    (10, 'Giocattoli Educativi');

-- Inserimento dati nella tabella Product
INSERT INTO Product (ProductID, Name, CategoryID)
VALUES
    (1, 'Action Figure Supereroe', 1),
    (2, 'Bambola alla Moda', 2),
    (3, 'Set LEGO', 3),
    (4, 'Scacchi', 4),
    (5, 'Puzzle a Incastro', 5),
    (6, 'Robot Trasformabile', 6),
    (7, 'Auto da Corsa in Scala', 7),
    (8, 'Orso di Peluche Gigante', 8),
    (9, 'Monopoly', 9),
    (10, 'Kit Scientifico per Bambini', 10);

-- Inserimento dati nella tabella Region
INSERT INTO Region (RegionID, Name)
VALUES
    (1, 'Nord America'),
    (2, 'Europa'),
    (3, 'Asia'),
    (4, 'Africa'),
    (5, 'Oceania'),
    (6, 'America del Sud'),
    (7, 'Antartide'),
    (8, 'Medio Oriente'),
    (9, 'America Centrale'),
    (10, 'Caraibi');

-- Inserimento dati nella tabella State con nomi di nazioni
INSERT INTO State (StateID, Name, RegionID)
VALUES
    (1, 'Stati Uniti', 1),
    (2, 'Canada', 1),
    (3, 'Regno Unito', 2),
    (4, 'Germania', 2),
    (5, 'Giappone', 3),
    (6, 'Cina', 3),
    (7, 'Sud Africa', 4),
    (8, 'Egitto', 4),
    (9, 'Australia', 5),
    (10, 'Nuova Zelanda', 5);
    
-- Inserimento dati nella tabella Sales
INSERT INTO Sales (SalesID, ProductID, StateID, SaleDate, Quantity, Price)
VALUES
    (1, 1, 1, '2024-02-12', 10, 19.99),
    (2, 2, 1, '2024-02-13', 15, 29.99),
    (3, 3, 2, '2024-02-14', 20, 39.99),
    (4, 4, 2, '2024-02-15', 12, 24.99),
    (5, 5, 3, '2024-02-16', 8, 14.99),
    (6, 6, 4, '2024-02-17', 5, 34.99),
    (7, 7, 4, '2024-02-18', 7, 44.99),
    (8, 8, 5, '2024-02-19', 3, 54.99),
    (9, 9, 5, '2024-02-20', 6, 19.99),
    (10, 10, 6, '2024-02-21', 4, 29.99);
    
-- INIZIO ES. QUERY 

USE Toygroup; 

-- ES.1 -- Verificare che i campi definiti come PK siano univoci. 

SELECT 'Category' AS TABELLA, COUNT(CategoryID) AS ID, COUNT(DISTINCT CategoryID) AS CONFERMA
FROM Category
UNION
SELECT 'Product' AS TABELLA, COUNT(ProductID) AS ID, COUNT(DISTINCT ProductID) AS CONFERMA
FROM Product
UNION
SELECT 'Region' AS TABELLA, COUNT(RegionID) AS ID, COUNT(DISTINCT RegionID) AS CONFERMA
FROM Region
UNION
SELECT 'State' AS TABELLA, COUNT(StateID) AS ID, COUNT(DISTINCT StateID) AS CONFERMA
FROM State
UNION
SELECT 'Sales' AS TABELLA, COUNT(SalesID) AS ID, COUNT(DISTINCT SalesID) AS CONFERMA
FROM Sales;

-- ES.2 -- Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.  

SELECT 
    P.Name AS Prodotto,
    YEAR(S.SaleDate) AS Anno,
    SUM(S.Quantity * S.Price) AS Fatturato
FROM 
    Product P
JOIN
    Sales S USING (ProductID)
GROUP BY
    P.ProductID, YEAR(S.SaleDate)
ORDER BY
    P.Name, YEAR(S.SaleDate);

-- ES.3 -- CREATE VIEW TotalRevenuePerStatePerYear AS

SELECT
    ST.Name AS Nazione,
    YEAR(S.SaleDate) AS Anno,
    SUM(S.Quantity * S.Price) AS Fatturato
FROM
    State ST
JOIN
    Sales S USING (StateID)
GROUP BY
    ST.Name, YEAR(S.SaleDate)
ORDER BY
    YEAR(S.SaleDate) DESC, Fatturato DESC;

-- ES.4 -- Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 

SELECT
    C.Name AS Categoria,
    P.Name AS Prodotto,
    SUM(S.Quantity) AS 'Quantità Vendute'
FROM
    Category C
JOIN
    Product P USING (CategoryID)
JOIN
    Sales S USING(ProductID)
GROUP BY
    C.Name, P.Name
ORDER BY
    SUM(S.Quantity) DESC
LIMIT 1;

-- ES.5 -- Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 

INSERT INTO Sales (SalesID, ProductID, StateID, SaleDate, Quantity, Price) -- inserimento di nuovi prodotti per rispondere all'ultima domanda
VALUES
    (11, 1, 1, '2020-03-15', 17, 39.99),
    (12, 2, 2, '2021-07-22', 8, 24.99),
    (13, 3, 3, '2022-05-11', 12, 19.99),
    (14, 4, 1, '2023-09-05', 10, 29.99),
    (15, 5, 2, '2020-11-30', 6, 44.99),
    (16, 6, 3, '2021-02-14', 5, 54.99),
    (17, 7, 4, '2022-08-03', 9, 14.99),
    (18, 8, 5, '2023-04-17', 14, 34.99),
    (19, 9, 1, '2021-12-08', 11, 49.99),
    (20, 10, 2, '2022-06-27', 7, 64.99);

DELETE FROM Sales -- Eliminazione del prodotto 8 per rispondere alla domanda
WHERE SalesID IN (8, 18);

-- PRIMO METODO

SELECT P.ProductID AS Codice, P.Name AS Prodotto
FROM Product P
WHERE P.ProductID NOT IN (SELECT ProductID FROM Sales);

-- SECONDO METODO

SELECT P.ProductID AS Codice, P.Name AS Prodotto
FROM Product P
LEFT JOIN Sales S ON P.ProductID = S.ProductID
WHERE S.ProductID IS NULL;

-- ES.6 -- Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente). 

SELECT P.ProductID AS Codice, P.Name AS Prodotto, MAX(S.SaleDate) AS Ultima_vendita
FROM Sales S
JOIN Product P USING (ProductID)
GROUP BY Codice, Prodotto
ORDER BY Ultima_vendita DESC; 

-- BONUS: Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, 
-- il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati più di 
-- 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> aFalse).

SELECT 
    S.SalesID AS 'Codice documento',
    S.SaleDate AS 'Data',
    P.Name AS 'Nome prodotto',
    C.Name AS 'Categoria prodotto',
    ST.Name AS 'Stato',
    R.Name AS 'Regione',
    CASE
        WHEN DATEDIFF('2024-02-21', s.SaleDate) > 180 THEN 'ALERT'
        ELSE 'OK'
    END AS Più_di_180_giorni
FROM
    Sales S
        JOIN
    Product P USING (ProductID)
        JOIN
    Category C USING (CategoryID)
        JOIN
    State ST USING (StateID)
        JOIN
    Region R USING (RegionID)
ORDER BY Più_di_180_giorni;
